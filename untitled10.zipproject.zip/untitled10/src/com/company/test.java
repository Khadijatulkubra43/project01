/*Q) Write an inheritance hierarchy for classes Quadrilateral, Trapezoid, Parallelogram,
        Rectangle and Square. Use Quadrilateral as the superclass of the hierarchy. Specify the instance
        variables and methods for each class. The
private instance variables of Quadrilateral should be the x-y coordinate pairs for the four endpoints
        of the Quadrilateral. Write a program that instantiates objects of your classes and outputs
        each object’s area (except Quadrilateral).
        1 // Exercise 9.8 Solution: QuadrilateralTest.java
        2 // Driver for Exercise 9.8
        3*/
        4 public class QuadrilateralTest
5 {
        6 public static void main( String args[] )
        7 {
        8 // NOTE: All coordinates are assumed to form the proper shapes
        9 // A quadrilateral is a four-sided polygon
        10 Quadrilateral quadrilateral =
        11 new Quadrilateral( 1.1, 1.2, 6.6, 2.8, 6.2, 9.9, 2.2, 7.4 );
        12
        13 // A trapezoid is a quadrilateral having exactly two parallel sides
        14 Trapezoid trapezoid =
        15 new Trapezoid( 0.0, 0.0, 10.0, 0.0, 8.0, 5.0, 3.3, 5.0 );
        16
        17 // A parallelogram is a quadrilateral with opposite sides parallel
        18 Parallelogram parallelogram =
        19 new Parallelogram( 5.0, 5.0, 11.0, 5.0, 12.0, 20.0, 6.0, 20.0 );
        20
        21 // A rectangle is an equiangular parallelogram
        22 Rectangle rectangle =
        23 new Rectangle( 17.0, 14.0, 30.0, 14.0, 30.0, 28.0, 17.0, 28.0 );
        24
        25 // A square is an equiangular and equilateral parallelogram
        26 Square square =
        27 new Square( 4.0, 0.0, 8.0, 0.0, 8.0, 4.0, 4.0, 4.0 );
        28
        29 System.out.printf(
        30 "%s %s %s %s %s\n", quadrilateral, trapezoid, parallelogram,
        31 rectangle, square );
        32 } // end main
        33 } // end class QuadrilateralTest
        8 Chapter 9 Object-Oriented Programming: Inheritance
        Coordinates of Quadrilateral are:
        ( 1.1, 1.2 ), ( 6.6, 2.8 ), ( 6.2, 9.9 ), ( 2.2, 7.4 )
        Coordinates of Trapezoid are:
        ( 0.0, 0.0 ), ( 10.0, 0.0 ), ( 8.0, 5.0 ), ( 3.3, 5.0 )
        Height is: 5.0
        Area is: 36.75
        Coordinates of Parallelogram are:
        ( 5.0, 5.0 ), ( 11.0, 5.0 ), ( 12.0, 20.0 ), ( 6.0, 20.0 )
        Width is: 6.0
        Height is: 15.0
        Area is: 90.0
        Coordinates of Rectangle are:
        ( 17.0, 14.0 ), ( 30.0, 14.0 ), ( 30.0, 28.0 ), ( 17.0, 28.0 )
        Width is: 13.0
        Height is: 14.0
        Area is: 182.0
        Coordinates of Square are:
        ( 4.0, 0.0 ), ( 8.0, 0.0 ), ( 8.0, 4.0 ), ( 4.0, 4.0 )
        Side is: 4.0
        Area is: 16.0
        1 // Exercise 9.8 Solution: Point.java
        2 // Class Point definition
        3
        4 public class Point
5 {
        6 private double x; // x coordinate
        7 private double y; // y coordinate
        8
        9 // two-argument constructor
        10 public Point( double xCoordinate, double yCoordinate )
        11 {
        12 x = xCoordinate; // set x
        13 y = yCoordinate; // set y
        14 } // end two-argument Point constructor
        15
        16 // return x
        17 public double getX()
        18 {
        19 return x;
        20 } // end method getX
        21
        22 // return y
        23 public double getY()
        24 {
        25 return y;
        26 } // end method getY
        27
        28 // return string representation of Point object
        Exercises 9
        29 public String toString()
        30 {
        31 return String.format( "( %.1f, %.1f )", getX(), getY() );
        32 } // end method toString
        33 } // end class Point
        1 // Exercise 9.8 Solution: Quadrilateral.java
        2 // Class Quadrilateral definition
        3
        4 public class Quadrilateral
5 {
        6 private Point point1; // first endpoint
        7 private Point point2; // second endpoint
        8 private Point point3; // third endpoint
        9 private Point point4; // fourth endpoint
        10
        11 // eight-argument constructor
        12 public Quadrilateral( double x1, double y1, double x2, double y2,
        13 double x3, double y3, double x4, double y4 )
        14 {
        15 point1 = new Point( x1, y1 );
        16 point2 = new Point( x2, y2 );
        17 point3 = new Point( x3, y3 );
        18 point4 = new Point( x4, y4 );
        19 } // end eight-argument Quadrilateral constructor
        20
        21 // return point1
        22 public Point getPoint1()
        23 {
        24 return point1;
        25 } // end method getPoint1
        26
        27 // return point2
        28 public Point getPoint2()
        29 {
        30 return point2;
        31 } // end method getPoint2
        32
        33 // return point3
        34 public Point getPoint3()
        35 {
        36 return point3;
        37 } // end method getPoint3
        38
        39 // return point4
        40 public Point getPoint4()
        41 {
        42 return point4;
        43 } // end method getPoint4
        44
        45 // return string representation of a Quadrilateral object
        46 public String toString()
        47 {
        10 Chapter 9 Object-Oriented Programming: Inheritance
        48 return String.format( "%s:\n%s",
        49 "Coordinates of Quadrilateral are", getCoordinatesAsString() );
        50 } // end method toString
        51
        52 // return string containing coordinates as strings
        53 public String getCoordinatesAsString()
        54 {
        55 return String.format(
        56 "%s, %s, %s, %s\n", point1, point2, point3, point4 );
        57 } // end method getCoordinatesAsString
        58 } // end class Quadrilateral
        1 // Exercise 9.8 Solution: Trapezoid.java
        2 // Class Trapezoid definition
        3
        4 public class Trapezoid extends Quadrilateral
5 {
        6 private double height; // height of trapezoid
        7
        8 // eight-argument constructor
        9 public Trapezoid( double x1, double y1, double x2, double y2,
        10 double x3, double y3, double x4, double y4 )
        11 {
        12 super( x1, y1, x2, y2, x3, y3, x4, y4 );
        13 } // end of eight-argument Trapezoid constructor
        14
        15 // return height
        16 public double getHeight()
        17 {
        18 if ( getPoint1().getY() == getPoint2().getY() )
        19 return Math.abs( getPoint2().getY() - getPoint3().getY() );
        20 else
        21 return Math.abs( getPoint1().getY() - getPoint2().getY() );
        22 } // end method getHeight
        23
        24 // return area
        25 public double getArea()
        26 {
        27 return getSumOfTwoSides() * getHeight() / 2.0;
        28 } // end method getArea
        29
        30 // return the sum of the trapezoid's two sides
        31 public double getSumOfTwoSides()
        32 {
        33 if ( getPoint1().getY() == getPoint2().getY() )
        34 return Math.abs( getPoint1().getX() - getPoint2().getX() ) +
        35 Math.abs( getPoint3().getX() - getPoint4().getX() );
        36 else
        37 return Math.abs( getPoint2().getX() - getPoint3().getX() ) +
        38 Math.abs( getPoint4().getX() - getPoint1().getX() );
        39 } // end method getSumOfTwoSides
        40
        41 // return string representation of Trapezoid object
        Exercises 11
        42 public String toString()
        43 {
        44 return String.format( "\n%s:\n%s%s: %s\n%s: %s\n",
        45 "Coordinates of Trapezoid are", getCoordinatesAsString(),
        46 "Height is", getHeight(), "Area is", getArea() );
        47 } // end method toString
        48 } // end class Trapezoid
        1 // Exercise 9.8 Solution: Parallelogram.java
        2 // Class Parallelogram definition
        3
        4 public class Parallelogram extends Trapezoid
5 {
        6 // eight-argument constructor
        7 public Parallelogram( double x1, double y1, double x2, double y2,
        8 double x3, double y3, double x4, double y4 )
        9 {
        10 super( x1, y1, x2, y2, x3, y3, x4, y4 );
        11 } // end eight-argument Parallelogram constructor
        12
        13 // return width of parallelogram
        14 public double getWidth()
        15 {
        16 if ( getPoint1().getY() == getPoint2().getY() )
        17 return Math.abs( getPoint1().getX() - getPoint2().getX() );
        18 else
        19 return Math.abs( getPoint2().getX() - getPoint3().getX() );
        20 } // end method getWidth
        21
        22 // return string representation of Parallelogram object
        23 public String toString()
        24 {
        25 return String.format( "\n%s:\n%s%s: %s\n%s: %s\n%s: %s\n",
        26 "Coordinates of Parallelogram are", getCoordinatesAsString(),
        27 "Width is", getWidth(), "Height is", getHeight(),
        28 "Area is", getArea() );
        29 } // end method toString
        30 } // end class Parallelogram
        1 // Exercise 9.8 Solution: Rectangle.java
        2 // Class Rectangle definition
        3
        4 public class Rectangle extends Parallelogram
5 {
        6 // eight-argument constructor
        7 public Rectangle( double x1, double y1, double x2, double y2,
        8 double x3, double y3, double x4, double y4 )
        9 {
        10 super( x1, y1, x2, y2, x3, y3, x4, y4 );
        11 } // end eight-argument Rectangle constructor
        12
        12 Chapter 9 Object-Oriented Programming: Inheritance
        13 // return string representation of Rectangle object
        14 public String toString()
        15 {
        16 return String.format( "\n%s:\n%s%s: %s\n%s: %s\n%s: %s\n",
        17 "Coordinates of Rectangle are", getCoordinatesAsString(),
        18 "Width is", getWidth(), "Height is", getHeight(),
        19 "Area is", getArea() );
        20 } // end method toString
        21 } // end class Rectangle
        1 // Exercise 9.8 Solution: Square.java
        2 // Class Square definition
        3
        4 public class Square extends Parallelogram
5 {
        6 // eight-argument constructor
        7 public Square( double x1, double y1, double x2, double y2,
        8 double x3, double y3, double x4, double y4 )
        9 {
        10 super( x1, y1, x2, y2, x3, y3, x4, y4 );
        11 } // end eight-argument Square constructor
        12
        13 // return string representation of Square object
        14 public String toString()
        15 {
        16 return String.format( "\n%s:\n%s%s: %s\n%s: %s\n",
        17 "Coordinates of Square are", getCoordinatesAsString(),
        18 "Side is", getHeight(), "Area is", getArea() );
        19 } // end method toString
        20 } // end class Square