package com.company;
         /*   public class Rectangle
            {
                float length,width; //attributes of class rectangle
                public void Rectangle(){ ///constructor to initialize default values to the attributes
                    length = 1.0f;
                    width = 1.0f;
                }

                public float perimeter(){ //member functions
                    return 2*(length+width);
                }
                public float area(){
                    return (length*width);
                }

                public void setLength(float len)
                {
                    if(len >0.0f && len <20.0f)
                        length = len;
                    else
                        System.out.println("Invalid Length");
                }
                public void setWidth(float wid)
                {
                    if(wid >0.0f && wid <20.0f)
                        width = wid;
                    else
                        System.out.println("Invalid width");
                }
                public float getLength(){
                    return length;
                }
                public float getWidth(){
                    return width;
                }
            }*/

/*import java .util.*;
public class Rectangle
{
    public static void main(String[] args) {
        Rectangle obj = new Rectangle(); //object of class rectangle
        Scanner sc = new Scanner (System.in);
        float len,width;
        System.out.println("Enter the length of the Rectangle");
        len = sc.nextFloat();
        System.out.println("Enter the width of the Rectangle");
        width = sc.nextFloat();
        obj.setLength(len); //setting values to attributes of class rectangle
        obj.setWidth(width);
        System.out.println("Length of the triangle is : "+obj.getLength());
        System.out.println("Width of the triangle is : "+obj.getWidth());
        System.out.println("Area of the triangle is : "+obj.area());
        System.out.println("Perimeter of the triangle is : "+obj.perimeter());
    }

    private String getWidth() {
    }

    private String perimeter() {
    }

    private String area() {
    }

    private String getLength() {
    }

    private void setWidth(float width) {
    }

    private void setLength(float len) {
    }
}*/
//package myPackage;
class Rectangle{
    // define two fields
    double length, width;
    // define no arg constructor
    Rectangle()
    {
        length = 1;
        width = 1;
    }
    // define parameterized constructor
    Rectangle(double length, double width)
    {
        this.length = length;
        this.width  = width;
    }
    // define a method to return area
    double getArea()
    {
        return (length * width);
    }
    // define a method to return perimeter
    double getPerimeter()
    {
        return (2 * (length + width));
    }
}
public class Rectangle1 {

    public static void main(String[] args) {

        // create first object
        //and initialize with no arg constructor
        Rectangle rect1 = new Rectangle();

        // create first object
        //and initialize with no arg constructor
        Rectangle rect2= new Rectangle(15.0,8.0);

        System.out.println("Area of first object="+rect1.getArea());
        System.out.println("Perimeter of first object="+rect1.getPerimeter());
        System.out.println("Area of second object="+rect2.getArea());
        System.out.println("Perimeter of second object="+rect2.getPerimeter());
    }

}

