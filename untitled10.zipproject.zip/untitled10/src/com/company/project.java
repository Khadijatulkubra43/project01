package com.company;

import java.util.Scanner;

public class project {
    //declaring to hold player name
    private static String playerOne;
    private static String playerTwo;
    private static String currentPlayer;
    private static int playerNumber=1;
    //declare variable to hold player word
    private static String playerWord="";
    //declaring variable to hold Alphabets list
    private static String AlphabetsList="abcdefghijklmnopqrstuvwxyz";
    //declaring variable to store used letter
    private static String usedLetters="";


    public static void main(String[] args) {
        System.out.println("Welcome to scrabble game " + "\n Enter (Y) to start the game or Enter space to exit");
       if( new Scanner(System.in).next().equalsIgnoreCase("Y")){
           //prompt player name
           System.out.println("Enter player one name:");
           playerOne=new Scanner(System.in).next();
           System.out.println("Enter player two name:");
           playerTwo=new Scanner(System.in).next();
           //calling a method to start game
           startGame();

       }
       else{
           //existing the program
           System.exit(0);
       }
    }

      //this method to start a game
    private static void startGame() {
        //while loop to loop the game
        while (!playerWord.equals("###")){
            //declarin current player
            currentPlayer();
            System.out.println("Remaining Alphabets:" +updateAlphabets());
            System.out.println(currentPlayer +  "Enter a word:");
            playerWord=new Scanner(System.in).next();
            

        }
    }
    //method declaring current player
    private static void currentPlayer() {
        if(playerNumber==1){
            currentPlayer=playerOne;
            playerNumber+=1;
        }
        else{
            currentPlayer=playerTwo;
            playerNumber-=1;
        }

    }

    //this method to updateAlphabets list
    private static String updateAlphabets() {
        //for loop fo Alphabetslist
        for(int i=0; i<AlphabetsList.toCharArray().length; i++){
            //get used letters
            if(playerWord.contains(AlphabetsList.toCharArray()[i]+ " ")){
                usedLetters=(AlphabetsList.toCharArray()[i]+" ");
                AlphabetsList=AlphabetsList.replace(AlphabetsList.toCharArray()[i] + "  ", " _ ");

            }
        }
        return AlphabetsList;
    }
}
