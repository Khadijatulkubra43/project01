package com.company;

import java.util.Scanner;

public class addition {
    public static void main(String[] args) {
        int a[][]=new int[2][2];
        int b[][]=new int[2][2];
        int c[][]=new int[2][2];
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter first matrix num");
        for (int k=0; k < 2; k++) {
            for (int l=0; l < 2; l++) {
                a[k][l]=sc.nextInt();

            }
        }
            System.out.print("Enter second matrix num");
            for (int k=0; k < 2; k++) {
                for (int l=0; l < 2; l++) {
                    b[k][l]=sc.nextInt();

                }
            }
                System.out.print("1st matrix");
                for ( int k=0; k < 2; k++) {
                    for (int l=0; l < 2; l++) {
                        System.out.print(a[k][l] + " ");
                    }
                    System.out.print("\n");

                }
                System.out.print("2nd matrix");
                for (int k=0; k < 2; k++) {
                    for (int l=0; l< 2; l++) {
                        System.out.print(b[k][l] + " ");
                    }
                    System.out.print("\n");

                }
              //  System.out.println("The sum of matrix is");
               System.out.println("The multiplication of matrix is");
                for (int k=0; k<2; k++){
                    for(int l=0; l<2; l++){
                       // c[k][l]=a[k][l]+b[k][l];
                       // c[k][l]=a[k][l]*b[k][l];
                       // c[k][l]=a[k][l]-b[k][l];

                        System.out.print(c[k][l] + " ");

                    }
                    System.out.print("\n");

                }

        }
    }

